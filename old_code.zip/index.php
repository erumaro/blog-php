<?php include("header.php"); ?>
    <?php // if($user = "admin"){ ?>
        <?php // include("admin.php"); ?>
    <?php // } else{ ?>
        <?php include("content.php"); ?>
    <?php // } ?>
<?php include("footer.php"); ?>