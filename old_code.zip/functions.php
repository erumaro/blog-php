<?php

$site_title = "Tobias Åruds blogg";
$site_desc = "This is my wonderful blog";


$db = new PDO("mysql:host=localhost;dbname=blog_db;", "root", "");
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

try{
$stmt = $db->query("SELECT * FROM blog_tbl");
$blog = $stmt->fetchAll(PDO::FETCH_ASSOC);	
} catch(PDOexception $e){
	echo $e->getMessage();
}

?>