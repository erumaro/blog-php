<article class="post">
    <header class="entry-header">
        <h1 class="entry-title"><?php echo $entry_title; ?></h1>
    </header>
    <div class="entry-content">
        <?php echo $entry_content; ?>
    </div>
    <footer class="entry-footer">
        <span class="author"><?php echo $author ?></span> | <time></time>
    </footer>
</article>