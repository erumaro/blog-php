<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php include("functions.php"); ?>
    <title><?php echo $site_title; ?></title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
	<header id="masthead" class="site-header" role="banner">
		<div class="site-branding">
			<h1 class="site-title"><?php echo $site_title; ?></h1>
			<p class="site-description"><?php echo $site_desc; ?></p>
		</div><!-- .site-branding -->

		<nav id="site-navigation" class="main-navigation" role="navigation">
            <!-- NAVIGATION HERE -->
		</nav><!-- #site-navigation -->
	</header><!-- #masthead -->

	<div id="content" class="site-content">